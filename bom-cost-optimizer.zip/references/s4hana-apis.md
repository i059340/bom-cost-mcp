# S/4HANA Cloud API 配置参考

本文档记录成本优化 Agent 所需的 S/4HANA Cloud API 配置信息。

---

## 已配置的 Communication Arrangements

| API 技术名 | Communication Scenario | 用途 | 状态 |
|-----------|----------------------|------|------|
| `API_BILL_OF_MATERIAL_SRV_0002` | `SAP_COM_0105` | BOM 结构展开 | ✅ 已建 |
| `API_PRODUCT_SRV` | `SAP_COM_0009` | 物料主数据（含标准成本） | ✅ 已建 |
| `API_INFORECORD_PROCESS_SRV` | `SAP_COM_0145` | 采购价历史 / Info Record | ✅ 已建 |
| `API_PURCHASING_SOURCE_SRV` | `SAP_COM_0162` | 来源清单（供应商数量） | ✅ 已建 |

---

## S/4HANA 系统信息

- **API Base URL**：`https://my409379-api.s4hana.cloud.sap`
- **BTP Destination 名称**：`S4HANA_COST_OPT`
- **认证方式**：BasicAuthentication
- **Communication User**：`BTP_COST_OPT`

---

## 关键 API 端点

### BOM 展开
```
GET /sap/opu/odata/sap/API_BILL_OF_MATERIAL_SRV_0002/MaterialBOMItem
    ?$filter=Material eq '{material}' and Plant eq '{plant}'
    &$expand=to_BOMItemComponent
```

### 物料主数据（标准成本）
```
GET /sap/opu/odata/sap/API_PRODUCT_SRV/A_ProductPlant('{material}','{plant}')
    ?$select=StandardPrice,PriceUnitQty,ValuationClass
```

### 采购价历史
```
GET /sap/opu/odata/sap/API_INFORECORD_PROCESS_SRV/A_PurchasingInfoRecord
    ?$filter=Material eq '{material}'
    &$expand=to_PurchasingInfoRecordPricingCondition
```

### 来源清单
```
GET /sap/opu/odata/sap/API_PURCHASING_SOURCE_SRV/A_PurchasingSource
    ?$filter=Material eq '{material}' and Plant eq '{plant}'
```

---

## MCP 工具映射

当 MCP 服务部署完成后，以下工具名将可用：

| MCP 工具名 | 对应 API | 参数 |
|-----------|---------|------|
| `get_product_master` | API_PRODUCT_SRV | material, plant |
| `get_bom_explosion` | API_BILL_OF_MATERIAL_SRV_0002 | material, plant, levels |
| `get_price_history` | API_INFORECORD_PROCESS_SRV | material, vendor(可选) |
| `get_source_list` | API_PURCHASING_SOURCE_SRV | material, plant |
