# S/4HANA MCP 连接器搭建指引

本文档说明如何将 S/4HANA Cloud 的 OData API 封装为 MCP 服务并注册到 Joule Desktop。

---

## 已完成的前置工作

✅ Step 1：S/4HANA Communication Arrangements（4 个）
✅ Step 2.1：BTP CF Space（trial / dev，4GB 内存）
✅ Step 2.2：BTP Destination `S4HANA_COST_OPT`

---

## 待完成：Step 2.3 — 部署 CAP MCP 服务

### 前提条件
- Node.js 18+
- CF CLI（`cf` 命令行工具）
- SAP CDS SDK（`@sap/cds`）

### 安装工具
```bash
npm install -g @sap/cds-dk
npm install -g cf
cf login -a https://api.cf.eu10.hana.ondemand.com
```

### 项目结构
```
cost-optimizer-mcp/
├── package.json
├── mta.yaml
├── xs-app.json
└── srv/
    └── mcp-server.js   # MCP 工具实现
```

### 核心代码（srv/mcp-server.js）

MCP 服务需暴露以下工具端点：
- `POST /mcp/tools/get_product_master`
- `POST /mcp/tools/get_bom_explosion`
- `POST /mcp/tools/get_price_history`
- `POST /mcp/tools/get_source_list`

每个工具从 BTP Destination `S4HANA_COST_OPT` 读取数据并返回 JSON。

### 部署命令
```bash
cd cost-optimizer-mcp
npm install
cf push cost-optimizer-mcp --memory 256M
```

### 部署成功后
应用 URL 格式：
```
https://cost-optimizer-mcp.cfapps.eu10.hana.ondemand.com
```

---

## Step 2.4 — 在 Joule Desktop 注册 MCP Connector

1. 打开 Joule Desktop → **Extensions**
2. 点 **+ Add Connector**
3. 填写：
   - Name：`S4HANA Cost Optimizer`
   - URL：`https://cost-optimizer-mcp.cfapps.eu10.hana.ondemand.com/mcp`
4. 保存后，本 Skill 即可自动调用 S/4HANA 数据
