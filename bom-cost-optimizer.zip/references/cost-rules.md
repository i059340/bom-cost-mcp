# 四维降本规则库

基于海尔全周期成本管理方法论，共 14 条可量化降本规则。

---

## 向模块要成本（目标 ~2.0%）

### 规则 M1：引入第二供应商
- **触发条件**：高成本组件 Source List 供应商数 = 1，且近 3 年采购价未下降
- **降本公式**：current_price × 0.06 × annual_volume（多供竞价降价约 6%）
- **典型案例**：压缩机 10010718975，单一供应商无竞价
- **SAP 落地**：Quota Arrangement（主供 65%/备供 35%）+ Source List + Vendor Evaluation
- **必须核实**：source_list_count、price_trend_3yr

### 规则 M2：PCB/电控模块整合
- **触发条件**：同一产品 BOM 中存在 3 块以上独立 PCB/电控板
- **降本公式**：(pcb_count - 1) × avg_pcb_price × 0.25（整合节省开发+采购+库存约 25%）
- **SAP 落地**：PLM ECO + Versioned BOM + Change Record
- **必须核实**：pcb_component_count

### 规则 M3：包装材料替代
- **触发条件**：包装物料为 EPS 泡沫，用量 > 300KG/千台
- **降本公式**：eps_weight × price_per_kg × 0.20（替代材料降价约 20%）
- **SAP 落地**：BOM Alternative Material + ECO Effectivity
- **必须核实**：packaging_material_type、annual_usage_kg

### 规则 M4：骨架/垫片规格统一
- **触发条件**：骨架总成中垫片/胶垫规格数 > 10 种
- **降本公式**：(spec_count - 6) × avg_sku_cost × 0.18（SKU 归并后集采降价约 18%）
- **SAP 落地**：KMAT BOM + Object Dependency + Outline Agreement
- **必须核实**：skeleton_spec_count

---

## 向产品要成本（目标 ~1.5%）

### 规则 P2：结构件轻量化
- **触发条件**：室外机钣金厚度 ≥ 1.2mm 且未做刚性优化分析
- **降本公式**：sheet_metal_weight × 0.15 × material_price（减薄 1.2→1.0mm，降重约 15%）
- **SAP 落地**：PLM ECO + BOM Alternative + Versioned BOM
- **必须核实**：sheet_metal_thickness

### 规则 P3：紧固件型号统一
- **触发条件**：BOM 中紧固件型号数 > 5 种用于相近装配场景
- **降本公式**：(fastener_sku_count - 3) × avg_sku_mgmt_cost（归并至 3 种标准规格）
- **SAP 落地**：BOM Deletion Flag + ECO Effectivity Date + Change Record
- **必须核实**：fastener_sku_count

### 规则 P4：管路/线束走线优化
- **触发条件**：BOM 中物料描述含“管”（油管、气管、水管等）或“线”（线束、线缆、信号线等）的组件数量 ≥ 3 种
- **降本公式**：tube_wire_total_cost × 0.05（优化走线方式减少用量/长度，降本约 5%）
- **典型案例**：整车线束 $380 + 交流输入线 $85 + 按键线束 $28 + 信号线缆 $22 = $515，走线优化节省 $26/台
- **SAP 落地**：PLM ECO + BOM 用量修改 + Cost Estimate 重新评估
- **验证门控**：P3 阶段需确认走线优化不影响信号完整性、液压压力、散热性能及安全功能
- **必须核实**：component_description_contains_tube_wire、tube_wire_component_count（≥ 3）、tube_wire_total_cost

---

## 向供应链要成本（目标 ~3.0%）

### 规则 S1：紧固件集中采购
- **触发条件**：紧固件分散采购，无年度框架协议（Outline Agreement）
- **降本公式**：total_fastener_spend × 0.175
- **SAP 落地**：Outline Agreement + Source List 绑定
- **必须核实**：outline_agreement_exists

### 规则 S2：铜管大宗商品套期保值
- **触发条件**：铜管采购无套期保值安排，铜价季度波动 > 5%
- **降本公式**：copper_annual_spend × 0.03
- **SAP 落地**：SAP TRM 套保头寸配置
- **必须核实**：hedging_arrangement_exists、copper_price_volatility

### 规则 S3：辅料组整合
- **触发条件**：BOM 中辅料分组数 > 3 个独立组
- **降本公式**：auxiliary_group_count × group_mgmt_cost × 0.40
- **SAP 落地**：BOM 重构 + ME2O 实时库存监控
- **必须核实**：auxiliary_group_count

### 规则 S4：关键件双供引入
- **触发条件**：压缩机或核心电控模块仅有单一供应商
- **降本公式**：与规则 M1 合并计算，避免重复
- **SAP 落地**：Quota Arrangement + Vendor Evaluation 综合评分
- **必须核实**：source_list_count for key components

### 规则 S5：齿轮/减速器 Make-to-Buy 外包
- **触发条件**：BOM 中物料描述含“齿轮”或“减速器”的组件为自制件（isAssembly = true），且存在完整子 BOM
- **降本公式**：gear_reducer_self_cost × 0.30
- **典型案例**：齿轮泵 EP-31004001（$680，isAssembly=true），切外采节省 $204/台
- **SAP 落地**：PLM ECO + Source List + 自制 BOM Deletion Flag + 供应商询价
- **验证门控**：TDS 评審，确认供应商工艺能力满足设计要求
- **必须核实**：component_description_contains_gear_reducer、component_is_assembly、gear_reducer_self_cost

### 规则 S6：电池系统二线品牌多供降本
- **触发条件**：BOM 中电池系统/电池模组（物料描述含“电池”或“BMS”）为最高成本组件，且 Source List 供应商数 ≤ 1
- **降本公式**：battery_system_cost × 0.10（引入功能参数相同、品牌溢价较低的二线供应商，多供配额竞价降本约 10%）
- **典型案例**：锤电池系统总成 EP-20001000（$12,160，33.4%）/ 电池模组 BMS EP-21001000（$9,800，26.9%），引入功能参数等效的二线品牌电芯供应商，配额：主供 60%/备供 40%，预计节省 $980~$1,216/台
- **供应商选型标准**：电芯输出容量/电压/循环寿命/温度范围等技术指标与现供商等效 + CE/UN38.3 认证 + 3C 认证 + 产线审评通过
- **SAP 落地**：Quota Arrangement（主供 60%/备供 40%）+ Source List 新增记录 + Vendor Evaluation 评分 + SRM 寻源事件
- **验证门控**：P3 验证阶段需确认备用供应商电池通过整机电性能测试、安全测试（梁邨、过充、针刺等）及循环寿命测试
- **必须核实**：battery_component_cost、source_list_count、functional_spec_equivalence

---

## 向生产要成本（目标 ~0.5%）

### 规则 G1：预装工序合并
- **触发条件**：同类辅料（如油漆+泡棉）分两道独立预装工序
- **降本公式**：merge_count × 0.2h × labor_rate
- **SAP 落地**：Routing 工序合并 + 标准工时重新核定
- **依赖条件**：需在模块/产品优化 BOM 简化后方可执行
- **必须核实**：pre_assembly_operation_count

### 规则 G2：辅料定额管控
- **触发条件**：辅料无精确 BOM 定额或损耗系数未设置
- **降本公式**：auxiliary_spend × 0.05
- **SAP 落地**：Backflush 配置 + BOM 损耗系数（1.05-1.10）+ VarianceAnalysis
- **必须核实**：bom_scrap_factor_configured

---

## 使用说明

每条规则的「必须核实」字段是数据溯源校验的检查项。
若相关数据无法从 S/4HANA 读取到，该规则对应建议应标记「依据不足」并剔除。

**S6 与 M1/S4 的区别**：M1/S4 为通用多供规则（杀价 6%）；S6 专针电池系统，允许常评下等品牌溃价策略，杀价 10%，需附加认证/寻源/验证流程。